package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.model.Cart;

public class CartServiceImpl implements CartService {

	@Override
	public List<Cart> retriveAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(String email, int quantity, int productId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Cart> delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Cart> findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cart> findByUserId(int userId) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

}
