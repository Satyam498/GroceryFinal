package com.cg.obs;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDetailsApplicationTests {
	

	}
	
	