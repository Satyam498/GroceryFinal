export class Cart{
    cartId:number;
   customerId:number;
    productId:number;
    quantity:number;
    productName:String;
    productPrice:String;
    
}