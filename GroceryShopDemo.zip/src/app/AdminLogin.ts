export class AdminLogin{
    adminId:string;
    adminPass:string;
}