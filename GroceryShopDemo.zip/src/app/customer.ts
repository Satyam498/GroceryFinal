export class customer{
	userId:number;
	fname : string;
	lname: string;
	email : string;
	mobile : string;
	address : string;
	
}