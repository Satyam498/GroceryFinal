import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { products } from './products';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { 

  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

 

  getProducts(): Observable<products> {
    return this.http.get<products>('http://localhost:9111/getProducts');
    
  }

  delete(productId: number) {

    return this.http.delete<products>('http://localhost:9111/delete/'+productId);
  }

  addProduct(products) {
    return this.http.post<products>('http://localhost:9111/add',products);
  }
  
  updateProduct(products,productId:number) {
    return this.http.put<products>('http://localhost:9111/update/'+productId,products);

  }
  public searchProductbyCategory(productCategory: String){
    return this.http.get<products[]>('http://localhost:9111/search/'+productCategory);
  }


  findById(productId:number){
    return this.http.get<products>('http://localhost:9111'+productId);
  }


  deleteAll(){
    console.log("inside deleteall");
    return this.http.delete<products>('http://localhost:9111');
  }




 
}
