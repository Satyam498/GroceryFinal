export class loginCredential{
    userId:number;
    username:string;
    password:string;
    role:string;
}