import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { products } from './products';
import { Cart } from './cart';

@Injectable({
  providedIn: 'root'
})
export class CartService {
idAfterLogin:any;
 
 cart : Cart=new Cart();
  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  // addCart(userId:any,quantity:any,product:any){
  //   console.log(`http://localhost:9090/add/`+userId,quantity,product);
  //   return this.http.post<Cart>(`http://localhost:9090/add/`+userId,quantity,product);
  // }
 
  addCart(customer: any, product: any,quantity: any) {
    // console.log('medicine id is ', medicine);
    console.log("Insidee cart service");
    console.log('user email is ', customer);
  //  console.log('user id is ', customer.customerId);
    console.log('qty',quantity);
    console.log('product id is ', product);
    // tslint:disable-next-line: max-line-length
    // /add/{email}/{quantity}/{productId}
   return this.http.post<any>(`http://localhost:2222/add?email=${customer}&quantity=${quantity}&productId=${product}`,{});
   // return this.http.post<Cart>(`http://localhost:2222/add/`${customer}+`/`+${quantity}+`/`+${product);
  
  }

  getCart(customerId: number) {
    console.log('id is ', customerId);
    return this.http.get<Cart>(`http://localhost:2222/findById/`+customerId);
  }

  // deleteCart(cartId: any) {
  //   return this.http.delete<any>(`http://localhost:8082/delete?id=${cartId}`);
  // }

}

