export class products{
    productId:number;
    productName:string;
    productCategory:string;
    productPrice:number;
    availability:string;
    quantity:string;
}